from django.contrib import admin
from . models import Data

# Register your models here.
admin.site.register(Data)
